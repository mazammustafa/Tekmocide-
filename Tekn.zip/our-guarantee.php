<?php include 'header.php' ?>

<section class="guarantee-inner-page">
    <div class="container">
        <h6> Our Guarantee</h6>
        <h1> Why Compomise When <br> <span>You Can Get the Best</span><strong>.</strong> </h1>
        <p> We guarantee Your Exceptional Work! </p>
    </div>
</section>

<section class="guarantee-inner-sect-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 content">
                <div class="guarantee-inner-content">
                    <h1> We Guarantee <span>100% Satisfaction</span><strong>.</strong></h1>
                    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                </div>
            </div>
            <div class="col-lg-6 image">
                <div class="guarantee-inner-img">
                    <img class="img-fluid" src="images/guarantee-1.png" alt="Guarantee image">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="guarantee-inner-img">
                    <img class="img-fluid" src="images/guarantee-2.png" alt="Guarantee image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="guarantee-inner-content">
                    <h1> We Guarantee <span>IMMACULATE DESIGNS</span><strong>.</strong></h1>
                    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6 content">
                <div class="guarantee-inner-content">
                    <h1> We Guarantee <span>1FASTEST TURNAROUND TIME</span><strong>.</strong></h1>
                    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                </div>
            </div>
            <div class="col-lg-6 image">
                <div class="guarantee-inner-img">
                    <img class="img-fluid" src="images/guarantee-3.png" alt="Guarantee image">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="guarantee-inner-img">
                    <img class="img-fluid" src="images/guarantee-4.png" alt="Guarantee image">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="guarantee-inner-content">
                    <h1> We Guarantee <span>MONEYBACK</span><strong>.</strong></h1>
                    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                        the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                        of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                        but also the leap into electronic typesetting, remaining essentially unchanged. </p>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include 'footer.php' ?>