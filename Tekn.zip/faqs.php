<?php include 'header.php' ?>

<section class="faq-inner-page">
    <div class="container">
        <h6> Faqs</h6>
        <h1> Everything You <br> <span>Need To Know</span><strong>.</strong> </h1>
        <p> Find Answere To Your Queries Or Contact Us! </p>
    </div>
</section>

<section class="faq-inner-sect-2">
    <div class="container">
        <h1> Our <span>FAQs</span><strong>.</strong></h1>
        <div class="faq-content">
            <div class="row">
                <div class="col-lg-6">
                    <div class="faq-container">
                        <button class="accordion"> <span>01</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown
                            </p>
                        </div>

                        <button class="accordion"> <span>02</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
                        </div>

                        <button class="accordion"><span>03</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown </p>
                        </div>

                    </div>

                </div>
                <div class="col-lg-6">
                    <div class="faq-container">
                        <button class="accordion"> <span>04</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown
                            </p>
                        </div>

                        <button class="accordion"> <span>05</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
                        </div>

                        <button class="accordion"><span>06</span> Will my design be unique ?</button>
                        <div class="panel">
                            <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                                has been the industry's standard dummy text ever since the 1500s, when an unknown</p>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php' ?>