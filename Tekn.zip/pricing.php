
<section class="pricing-section">
    <div class="container">
        <div class="pricing-heading">
            <h6> Best Digital Resolutions </h6>
            <h1> Friendly - <span>Pricing Solutions</span><strong>.</strong></h1>
            <p> We understand the affordability concern and tend to offer highly economical <br> pricing packages to
                make our
                expertise available for all. </p>
            <div class="tab">
                <button class="tablinks active" onclick="openCity(event, 'web-pack')">Website Packages</button>
                <button class="tablinks" onclick="openCity(event, 'logo-pack')">Logo Packages</button>
                <button class="tablinks" onclick="openCity(event, 'app-design')">App Design</button>
                <button class="tablinks" onclick="openCity(event, 'app-design')">App Design</button>
                <button class="tablinks" onclick="openCity(event, 'app-design')">App Design</button>
                <button class="tablinks" onclick="openCity(event, 'app-design')">App Design</button>
                <!-- <button class="tablinks" onclick="openCity(event, 'consultation')">Consultation</button> -->

            </div>
        </div>
        <div id="web-pack" class="tabcontent" style="display:block;">
            <div class="row">
                <div class="pricing-content">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Instant Website </h5>
                                <h1> $79 </h1>
                                <h6> $90 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Website Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Standard Website </h5>
                                <h1> $109 </h1>
                                <h6> $120 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Website Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Prime Website </h5>
                                <h1> $199 </h1>
                                <h6> $150 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Website Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Another Website </h5>
                                <h1> $199 </h1>
                                <h6> $150 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Website Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="logo-pack" class="tabcontent">
            <div class="row">
                <div class="pricing-content">
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Instant Logo </h5>
                                <h1> $79 </h1>
                                <h6> $90 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Logo Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Standard Logo </h5>
                                <h1> $109 </h1>
                                <h6> $120 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Logo Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Prime Logo </h5>
                                <h1> $199 </h1>
                                <h6> $150 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Logo Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="pricing-card slide">
                            <div class="pricing-card-heading">
                                <h5> Another Logo </h5>
                                <h1> $199 </h1>
                                <h6> $150 </h6>
                            </div>
                            <div class="pricing-card-content">
                                <h4> Logo Design </h4>
                                <ul>
                                    <li> Inner Pages </li>
                                    <li> (CMS) </li>
                                    <li> Mobile Responsive </li>
                                    <li> 5 Stock Photos + 3 Banner Design </li>
                                    <li> Any 3 social media platform </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                    <li> Complete W3C certified </li>
                                    <li> HTML </li>
                                </ul>
                                <div class="pricing-btn">
                                    <a href="#!"> Get Started </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="app-design" class="tabcontent">
            <h3>App Design</h3>
            <p>Tokyo is the capital of Japan.</p>
        </div>

        <div id="app-design" class="tabcontent">
            <h3>App Design</h3>
            <p>Tokyo is the capital of Japan.</p>
        </div>

        <div id="app-design" class="tabcontent">
            <h3>App Design</h3>
            <p>Tokyo is the capital of Japan.</p>
        </div>

        <div id="app-design" class="tabcontent">
            <h3>App Design</h3>
            <p>Tokyo is the capital of Japan.</p>
        </div>

    </div>
</section>
